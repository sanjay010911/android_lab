package com.example.customgridapp;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.widget.AdapterView;
import android.widget.Toast;
import android.widget.GridView;
import android.view.View;
public class MainActivity extends AppCompatActivity {

    GridView gridview;
    String []items={"Add","Comment","Photo","Search"};
    int[] imageids={R.drawable.add,R.drawable.comment,R.drawable.photo,R.drawable.search};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        gridview=findViewById(R.id.grid);
        CustomAdapter adapter=new CustomAdapter(items,imageids,MainActivity.this);
        gridview.setAdapter(adapter);
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String text=items[i];
                Toast.makeText(MainActivity.this,"You selected "+text,Toast.LENGTH_SHORT).show();
            }
        });
    }
}