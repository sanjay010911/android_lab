package com.example.customgridapp;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Context;
import android.view.LayoutInflater;

import java.net.ConnectException;

public class CustomAdapter extends BaseAdapter {
    private Context context;
    private final String[] items;
    private final int[] ImageIds;

    public CustomAdapter(String[] items, int[] imageIds, Context context) {
        this.context = context;
        this.ImageIds = imageIds;
        this.items=items;
    }

    public int getCount(){
        return items.length;
    }

    @Override
    public Object getItem(int i) {
        return items[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
       View gridviewitem;
       if(view == null)
       {
           LayoutInflater inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
           gridviewitem=inflater.inflate(R.layout.grid_item,viewGroup,false);
       }
       else {
           gridviewitem=view;

       }
       TextView textview=gridviewitem.findViewById(R.id.g);
       ImageView imageview=gridviewitem.findViewById(R.id.imageView2);
       textview.setText(items[i]);
       imageview.setImageResource(ImageIds[i]);
       return gridviewitem;
    }
}
