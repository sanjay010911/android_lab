package com.example.thread1;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {
private TextView progressText;
private Button btn;
private ProgressBar progressBar;
//create a counter variable
private int progress=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        progressText=findViewById(R.id.tv);
        progressBar=findViewById(R.id.progressBar2);
        btn=findViewById(R.id.button);
    }
    public void submit(View view)
    {
        btn.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        new Thread(new Runnable(){
            public void run(){
                //write the code to be executed inside thread
                for(progress=0;progress<=100;progress++)
                {
                    try{
                        Thread.sleep(50);
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                    //update textview and progress bar :ui thread
                    runOnUiThread(new Runnable() {

                        public void run() {
                            //code for ui updation
                            progressBar.setProgress(progress);
                            progressText.setText("Progress :"+progress+"%");
                        }
                    });//end the ui thread
                }//end for loop
                runOnUiThread(new Runnable() {

                    public void run() {
                        btn.setEnabled(true);
                        progressText.setText("Completed");
                        progressBar.setVisibility(View.GONE);
                    }
                });

            }
        }).start();
    }
}